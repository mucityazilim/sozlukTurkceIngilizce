#ifndef KELIME_H
#define KELIME_H

class Kelime
{
	public: 
	char tKelime[30]; 
	char iKelime[30]; 
};

#endif
