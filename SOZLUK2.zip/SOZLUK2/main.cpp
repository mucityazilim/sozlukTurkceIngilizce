#include <iostream>
#include "Sozluk.h"
using namespace std; 



int main(  ) {
	
	Sozluk nes; 
	nes.giris() ; 


	return 0;
}
