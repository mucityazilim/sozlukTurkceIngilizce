#ifndef SOZLUK_H
#define SOZLUK_H

class Sozluk
{
	private: 
	
	 
	void turkceIngilizce(); 
	void ingilizceTurkce(); 
	void kelimeEkle(); 
	void kelimeBul(); 
	void kelimeSil(); 
	void listele(); 
	int menu(); 
	int menuBul(); 
	public: 
	void giris(); 
	
		
};

#endif
